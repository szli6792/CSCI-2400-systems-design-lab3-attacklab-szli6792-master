/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_433()
{
    return 12800225U;
}

unsigned addval_391(unsigned x)
{
    return x + 2425378889U;
}

unsigned getval_460()
{
    return 3284633928U;
}

unsigned getval_470()
{
    return 3347663093U;
}

unsigned getval_482()
{
    return 2455265200U;
}

unsigned addval_299(unsigned x)
{
    return x + 3284633944U;
}

unsigned getval_267()
{
    return 3284601160U;
}

unsigned addval_179(unsigned x)
{
    return x + 683905112U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_404()
{
    return 3531132553U;
}

unsigned getval_265()
{
    return 3525366152U;
}

unsigned getval_363()
{
    return 3348156809U;
}

unsigned getval_407()
{
    return 3374894729U;
}

unsigned addval_445(unsigned x)
{
    return x + 3767093314U;
}

unsigned addval_245(unsigned x)
{
    return x + 3224949129U;
}

void setval_388(unsigned *p)
{
    *p = 3286272360U;
}

unsigned addval_308(unsigned x)
{
    return x + 3281047177U;
}

void setval_356(unsigned *p)
{
    *p = 3380924809U;
}

unsigned addval_355(unsigned x)
{
    return x + 2430638408U;
}

unsigned getval_338()
{
    return 3767077036U;
}

unsigned addval_247(unsigned x)
{
    return x + 3250751783U;
}

void setval_281(unsigned *p)
{
    *p = 2425406091U;
}

unsigned getval_283()
{
    return 3223372457U;
}

void setval_389(unsigned *p)
{
    *p = 2425537161U;
}

unsigned getval_287()
{
    return 3269495112U;
}

unsigned getval_360()
{
    return 3375944075U;
}

void setval_457(unsigned *p)
{
    *p = 3529559689U;
}

unsigned getval_358()
{
    return 3534016137U;
}

void setval_248(unsigned *p)
{
    *p = 3516469739U;
}

unsigned getval_119()
{
    return 3252717896U;
}

void setval_187(unsigned *p)
{
    *p = 3281047177U;
}

unsigned addval_321(unsigned x)
{
    return x + 3255390286U;
}

unsigned getval_126()
{
    return 3286272328U;
}

unsigned getval_487()
{
    return 2932064905U;
}

unsigned getval_382()
{
    return 3348156809U;
}

unsigned addval_401(unsigned x)
{
    return x + 3286273352U;
}

void setval_138(unsigned *p)
{
    *p = 3676357257U;
}

unsigned getval_396()
{
    return 3374371273U;
}

unsigned addval_225(unsigned x)
{
    return x + 3677408905U;
}

void setval_333(unsigned *p)
{
    *p = 3464618339U;
}

unsigned addval_479(unsigned x)
{
    return x + 3676881545U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
